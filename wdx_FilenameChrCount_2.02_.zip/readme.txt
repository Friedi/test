Filename ChrCount, WDX Content Plugin for Total Commander, 2005-2012 by J. Bleichroth

(Deutsche Übersetzung: siehe weiter unten in dieser Datei.)

Plugin columns: Pathname (ChrCount), Filename (ChrCount), Path (ChrCount), 
                Ext (ChrCount), Filename (ChrCount excl Ext), Path
                
Plugin purpose: Checking the length of pathnames of files and folders

---------------------------------------------------

Changelog:
2012-02-28 v2.02  Unicode support, 64bit (wdx64), add. columns Pathname, Path (full), Pathname (full)
2011-06-11 v1.06  Versions infos added, Development Environment (IDE and Compiler) changed
2005-02-18 v1.04  Plugin internal structure changed, readme.txt improved
2005-01-27 v1.02a Plugin Description added in Readme.txt
2005-01-24 v1.02  Text field "Path" added
2005-01-22 Initial release

---------------------------------------------------

Installation: 
- Standard: Open the plugin zip file (with a pluginst.inf file for automatic inst.) within TC
- Manual:   Use TC Menu -> Configuration -> Options -> Pugins -> 
            Content Plugins configure -> Add ...

---------------------------------------------------

Usage: 
- Use TC Menu -> Configuration -> Options -> Custom columns -> New/Edit ...
or
- Right-click on the (left or right) TC window columns - > Configure custom columns -> New/Edit ..

---------------------------------------------------

Support questions, bug reports, suggestions please here:
Total Commander Forum -> Plugins and addons: devel.+support (English)
Link: http://www.ghisler.ch/board/viewforum.php?f=6

---------------------------------------------------

License and liability:
Filename ChrCount, WDX Content Plugin for Total Commander, Copyright 2005-2012 J. Bleichroth
Any liability for damage of any sort is hereby denied.
All rights reserved. 
This Total Commander Plugin is free usable, copyrighted software by J. Bleichroth
Distribution reserved. No distribution without permission by J. Bleichroth.

===============================================================================

Deutsche Übersetzung:

Filename ChrCount, WDX Content Plugin für Total Commander, 2005-2012 von J. Bleichroth

Plugin Kolumnen: Pfadname (Anz Zeichen), Dateiname (Anz Zeichen), Pfad (Anz Zeichen)
                 Erw (Anz Zeichen), Dateiname (Anz Zeichen ohne Erw), Pfad
                 
Plugin Zweck:    Ermitteln der Länge von Pfadnamen von Dateien und Verzeichnissen

---------------------------------------------------

Changelog:
2012-02-28 v2.02  Unicode-Unterstützung, 64bit (wdx64), hinzugefügte Kolumnen Pfadname, Pfad (voll), Pfadname (voll)
2011-06-11 v1.06  Versions Infos hinzugefügt, Entwicklungumgebung (IDE and Compiler) gewechselt
2005-02-18 v1.04  Interne Plugin-Struktur geändert, readme.txt überarbeitet
2005-01-27 v1.02a Plugin Beschreibung zu Readme.txt hinzugefügt
2005-01-24 v1.02  Kolumne "Path" hinzugefügt
2005-01-22 Erste Veröffentlichung

---------------------------------------------------

Installation:
- Standard: Öffnen Sie das Plugin-Zip-Archiv (Mit einer pluginst.inf-Datei für die automatische Installation) 
            innerhalb vom TC mit Enter und folgen sie dann den Anweisungen des Tc
- Manuell:  TC Menü -> Konfiguration -> Optionen -> Pugins -> Inhalt Plugins configure -> Add ...

---------------------------------------------------

Benutzung:
- TC Menü -> Konfiguration -> Optionen -> Benutzerdefinierte Spalten -> Neu/Bearbeiten ...
oder
- Oberhalb vom (linken oder rechten) TC Fenster Kolumnen mit der rechten Maustaste klicken -> 
  Konfigurieren benutzerdefinierter Spalten -> Neu/Bearbeiten ..

---------------------------------------------------

Support-Anfragen, Fehlermeldungen, Anregungen bitte hier einstellen:
Total Commander Forum -> Plugins und Addons:. Devel + Support (englisch)
Link: http://www.ghisler.ch/board/viewforum.php?f=6

---------------------------------------------------

Lizenz und Haftung:
Filename ChrCount, WDX Content Plugin für Total Commander, Copyright 2005-2012 J. Bleichroth
Jegliche Haftung für Schäden jeglicher Art wird hiermit ausgeschlossen.
Alle Rechte vorbehalten.
Dieses Total Commander-Plugin ist kostenlos nutzbare, urheberrechtlich geschützte Software von J. Bleichroth.
Verteilung vorbehalten. Keine Verteilung ohne Genehmigung von J. Bleichroth.

---------------------------------------------------
