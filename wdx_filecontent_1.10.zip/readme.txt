FileContent 1.10
----------------

FileContent can be used in the search function in Total Commander. 
Navigate to the plugin tab and add one of the fields to the list. 

What's so great about this? I have the same options one the main search tab.
Well you can add all three fields and search for all supported files encodings at once. Try that using TC! It's limited to one encoding at once.